package com.example.atelier4;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.Arrays;
import java.util.List;


public class DisplayPhotos extends AppCompatActivity {
    RecyclerView picturesRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_photos);
        picturesRecyclerView = findViewById(R.id.picturesRecyclerView);
        setupPicturesRecyclerView();
    }

    private List<String> loadPictures() {
        File[] files = getFilesDir().listFiles((dir, name) -> name.endsWith(".jpg"));
        int taille = 0;
        if (files != null) {
            taille = files.length;
        }
        int i = 0;
        String[] paths = new String[taille];
        if (files != null) {
            for (File f:files)
                paths[i++] = f.getAbsolutePath();
        }
        return Arrays.asList(paths);
    }

    private void setupPicturesRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        picturesRecyclerView.setLayoutManager(layoutManager);
        List<String> pictures = loadPictures();
        PicturesAdapter adapter = new PicturesAdapter(pictures);
        picturesRecyclerView.setAdapter(adapter);
    }
}