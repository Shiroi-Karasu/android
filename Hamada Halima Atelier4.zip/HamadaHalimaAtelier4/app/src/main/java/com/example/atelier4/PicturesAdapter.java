package com.example.atelier4;

import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PicturesAdapter extends RecyclerView.Adapter<PicturesAdapter.ViewHolder> {

    private final List<String> picturePaths;

    public PicturesAdapter(List<String> picturePaths) {
        this.picturePaths = picturePaths;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.picture_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String picturePath = picturePaths.get(position);
        holder.pictureImageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));
    }

    @Override
    public int getItemCount() {
        return picturePaths.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView pictureImageView;

        public ViewHolder(View itemView) {
            super(itemView);
            pictureImageView = itemView.findViewById(R.id.pictureImageView);
        }
    }
}
