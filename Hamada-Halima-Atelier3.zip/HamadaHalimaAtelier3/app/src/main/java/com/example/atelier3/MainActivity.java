package com.example.atelier3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button login;
    EditText first_name;
    EditText last_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        UserSqlDatabase db = new UserSqlDatabase(this);
        db.open();

        login = findViewById(R.id.button);
        first_name = findViewById(R.id.PersonFirstName);
        last_name = findViewById(R.id.PersonLastName);

        login.setOnClickListener(v -> {
            String f_name = first_name.getText().toString();
            String l_name = last_name.getText().toString();
            if(f_name.equals("") || l_name.equals(""))
                Toast.makeText(this, "Fill all the text Fields please.", Toast.LENGTH_SHORT).show();
            else{
                UserSqlDatabase.insertUser(f_name,l_name);
                Intent intent = new Intent(getApplicationContext(), ShowDataActivity.class);
                startActivity(intent);
            }
        });
    }
}
