package com.example.atelier3;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ShowDataActivity extends AppCompatActivity {

    TableLayout data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_data);

        data = findViewById(R.id.dataTable);
        UserSqlDatabase db = new UserSqlDatabase(this);
        db.open();
        try (Cursor cursor = UserSqlDatabase.fetch()){
            while (cursor.moveToNext()) {
                TableRow newRow = new TableRow(this);

                TextView user_fname = new TextView(this);
                user_fname.setText(cursor.getString(1));
                user_fname.setTextSize(17);
                user_fname.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                newRow.addView(user_fname);

                TextView user_lname = new TextView(this);
                user_lname.setText(cursor.getString(2));
                user_lname.setTextSize(17);
                user_fname.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                newRow.addView(user_lname);

                data.addView(newRow);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error in reading from database!", Toast.LENGTH_SHORT).show();
        }
    }
}