package com.example.atelier3;

public class User {
    private int id;
    private String last_name,first_name;
}
