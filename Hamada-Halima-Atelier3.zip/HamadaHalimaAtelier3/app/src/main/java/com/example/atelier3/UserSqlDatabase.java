package com.example.atelier3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class UserSqlDatabase {
    private DatabaseHelper dbHelper;
    final private Context context;
    private static SQLiteDatabase database;
    public UserSqlDatabase(Context c) {
        context = c;
    }

    public UserSqlDatabase open() throws SQLException {
        dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    public static boolean insertUser(String firstname, String lastname) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.FirstNAME, firstname);
        contentValues.put(DatabaseHelper.LastNAME, lastname);
        database.insert("users", null, contentValues);
        return true;
    }

    public static Cursor fetch() {
        String[] columns = new String[] { DatabaseHelper.ID, DatabaseHelper.FirstNAME, DatabaseHelper.LastNAME };
        Cursor cursor = database.query(DatabaseHelper.TABLE_NAME, columns, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }
}
