package com.monProjet;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageButton;

import de.hdodenhof.circleimageview.CircleImageView;

public class HomeActivity extends AppCompatActivity {
    UserSqlDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        db = new UserSqlDatabase(this);
        db.open();

        Intent intent = getIntent();
        String user_email = intent.getStringExtra("email");

        CircleImageView profile = findViewById(R.id.image_profile);
        TextView name = findViewById(R.id.name);
        AppCompatImageButton activitiesOnTable = findViewById(R.id.activities);
        AppCompatImageButton activitiesOnMap = findViewById(R.id.map);
        AppCompatImageButton setting = findViewById(R.id.setting);
        AppCompatImageButton quit = findViewById(R.id.quit);

        User user = UserSqlDatabase.selectUser(user_email);

        name.setText(user.getUsername());

        if (user.getImagePath().equals(""))
            profile.setImageResource(R.drawable.user);// a changer

        setting.setOnClickListener(v -> {
            Intent newIntent = new Intent(getApplicationContext(), ProfileEditActivity.class);
            newIntent.putExtra("email", user_email);
            startActivity(newIntent);
        });

        activitiesOnTable.setOnClickListener(v -> {
            Intent newIntent = new Intent(getApplicationContext(), ViewActivitiesActivity.class);
            newIntent.putExtra("email", user_email);
            startActivity(newIntent);
        });

        activitiesOnMap.setOnClickListener(v -> {
            Intent newIntent = new Intent(getApplicationContext(), MapActivity.class);
            newIntent.putExtra("email", user_email);
            startActivity(newIntent);
        });

        quit.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Quit App");
            builder.setMessage("Are you sure you want to quit?");

            builder.setPositiveButton("Quit", (dialog, which) -> {
                db.close();
                this.finishAffinity();
                System.exit(0);
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

            AlertDialog dialog = builder.create();
            dialog.show();
        });
    }

    @Override
    protected void onDestroy() {
        db.close();
        super.onDestroy();
    }
}