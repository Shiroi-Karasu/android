package com.monProjet;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import de.hdodenhof.circleimageview.CircleImageView;
import androidx.appcompat.app.ActionBar;

public class ProfileEditActivity extends AppCompatActivity {
    UserSqlDatabase db;
    User user;
    String user_email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_edit);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Edit user profile");
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#62B1EF")));

        db = new UserSqlDatabase(this);
        db.open();

        CircleImageView profileImage = findViewById(R.id.image_profile);
        Button changeProfileImage = findViewById(R.id.change);
        EditText editName = findViewById(R.id.editName);
        EditText editEmail = findViewById(R.id.editEmail);
        EditText editPassword = findViewById(R.id.editPassword);
        EditText editPhone = findViewById(R.id.editPhone);
        EditText editMajor = findViewById(R.id.editMajor);
        RadioButton female = findViewById(R.id.radio_female);
        RadioButton male = findViewById(R.id.radio_male);

        Intent intent = getIntent();
        user_email = intent.getStringExtra("email");

        user = UserSqlDatabase.selectUser(user_email);

        editName.setText(user.getUsername());
        editEmail.setText(user.getEmail());
        editPassword.setText(user.getPassword());
        editPhone.setText(user.getPhone());
        editMajor.setText(user.getMajor());

        if (user.getSexe().equals("female"))
            female.setChecked(true);
        else
            male.setChecked(true);

        user.setEmail(editEmail.getText().toString());
        user.setPassword(editPassword.getText().toString());
        user.setUsername(editName.getText().toString());
        user.setPhone(editPhone.getText().toString());
        user.setMajor(editMajor.getText().toString());

        changeProfileImage.setOnClickListener(v->{
            user.setImagePath("myImage");// pour test

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Profile Picture Picker");
            //builder.setMessage("Are you sure you want to quit?");

            builder.setPositiveButton("Take from camera.", (dialog, which) -> {

            });

            builder.setNegativeButton("Select from gallery.", (dialog, which) -> {

            });

            builder.setNeutralButton("Cancel", (dialog, which) -> dialog.dismiss());

            AlertDialog dialog = builder.create();
            dialog.show();
        });

        female.setOnClickListener(v-> user.setSexe("female"));

        male.setOnClickListener(v-> user.setSexe("male"));
    }

    @Override
    protected void onDestroy() {
        db.close();
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.save) {
            if (user.getEmail().equals("") || user.getPassword().equals("") || user.getUsername().equals("")
                || user.getPhone().equals("") || user.getMajor().equals("")) {
                Toast.makeText(this, user.getPhone() + " -- " + user.getMajor(), Toast.LENGTH_SHORT).show();
                return true;
            }
            UserSqlDatabase.updateUser(user_email, user);
            Toast.makeText(this, "Changes saved.", Toast.LENGTH_SHORT).show();
            return true;
        }
        else {
            Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
            intent.putExtra("email", user_email);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

}