package com.monProjet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignInActivity extends AppCompatActivity {
    UserSqlDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        db = new UserSqlDatabase(this);
        db.open();

        Button signUp = findViewById(R.id.register);
        Button signIn = findViewById(R.id.login);
        EditText email = findViewById(R.id.email);
        EditText password = findViewById(R.id.password);

        signIn.setOnClickListener(v -> {
            String user_email = email.getText().toString();
            String user_password = password.getText().toString();
            if(user_password.equals("") || user_email.equals(""))
                Toast.makeText(this, "All Fields are required.", Toast.LENGTH_SHORT).show();
            else{
                User user = db.selectUser(user_email);
                if (user == null) {
                    Toast.makeText(this, "No such account...Please create a new one.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(this, SignUpActivity.class);
                    startActivity(intent);
                } else if (!(user.getPassword()).equals(user_password)) {
                    Toast.makeText(this, "Incorrect password", Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                    intent.putExtra("email", user_email);
                    startActivity(intent);
                }
            }
        });

        signUp.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), SignUpActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onDestroy() {
        db.close();
        super.onDestroy();
    }
}