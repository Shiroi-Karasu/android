package com.monProjet;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {
    UserSqlDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        db = new UserSqlDatabase(this);
        db.open();

        Button signUp = findViewById(R.id.register);
        Button signIn = findViewById(R.id.login);
        EditText email = findViewById(R.id.email);
        EditText password = findViewById(R.id.password);
        EditText username = findViewById(R.id.username);

        signUp.setOnClickListener(v->{
            String user_email, user_password, user_name;
            user_email = email.getText().toString();
            user_password = password.getText().toString();
            user_name = username.getText().toString();
            if(user_email.equals("") || user_password.equals("") || user_name.equals(""))
                Toast.makeText(this, "All text Fields are required.", Toast.LENGTH_SHORT).show();
            else{
                User user = UserSqlDatabase.selectUser(user_email);
                if (user == null) {
                    UserSqlDatabase.insertUser(user_email, user_password, user_name, "", "", "", "");
                    Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                    intent.putExtra("email", user_email);
                    startActivity(intent);
                }
                else
                    Toast.makeText(this, user.getEmail() + " already exist.\nPlease sign in or chose another one.", Toast.LENGTH_SHORT).show();
            }
            });

        signIn.setOnClickListener(v->{
            Intent intent = new Intent(this, SignInActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onDestroy() {
        db.close();
        super.onDestroy();
    }
}