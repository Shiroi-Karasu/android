package com.monProjet;

import androidx.annotation.NonNull;

public class User {
    private String email;
    private String password;
    private String username;
    private String phone;
    private String sexe;
    private String major;
    private String imagePath;

    public User(String email, String password, String username, String phone, String sexe, String major, String imagePath) {
        setEmail(email);
        setPassword(password);
        setUsername(username);
        setPhone(phone);
        setSexe(sexe);
        setMajor(major);
        setImagePath(imagePath);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email != null)
            this.email = email;
        else
            this.email = "";
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        if (password != null)
            this.password = password;
        else
            this.password = "";
    }
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        if (username != null)
            this.username = username;
        else
            this.username = "";
    }

    public String getSexe() {
        return sexe;
    }

    public void setSexe(String sexe) {
        if (sexe != null)
            this.sexe = sexe;
        else
            this.sexe = "male";
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        if (phone != null)
            this.phone = phone;
        else
            this.phone = "";
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        if (major != null)
            this.major = major;
        else
            this.major = "";
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        if (imagePath != null)
            this.imagePath = imagePath;
        else
            this.imagePath = "";
    }

    @NonNull
    @Override
    public String toString() {
        return this.getEmail() + "\n" + this.getPassword();
    }
}
