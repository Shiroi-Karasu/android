package com.monProjet;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class UserSqlDatabase {
    private DatabaseHelper dbHelper;
    final private Context context;
    private static SQLiteDatabase database;

    public UserSqlDatabase(Context c) {
        context = c;
    }

    public void open() throws SQLException {
        dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        //return this;
    }

    public void close() {
        dbHelper.close();
    }

    public static void insertUser(String email, String password, String username, String phone, String sexe, String major, String image) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.EMAIL, email);
        contentValues.put(DatabaseHelper.PASSWORD, password);
        contentValues.put(DatabaseHelper.USERNAME, username);
        contentValues.put(DatabaseHelper.PHONE, phone);
        contentValues.put(DatabaseHelper.SEXE, sexe);
        contentValues.put(DatabaseHelper.MAJOR, major);
        contentValues.put(DatabaseHelper.IMAGE, image);
        database.insert("USERS", null, contentValues);
    }

    public static Cursor fetch() {
        String[] columns = new String[] { DatabaseHelper.EMAIL, DatabaseHelper.USERNAME };
        Cursor cursor = database.query(DatabaseHelper.TABLE_NAME, columns, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }

    public static User selectUser(String email) {
        String[] columns = new String[] { DatabaseHelper.EMAIL, DatabaseHelper.PASSWORD, DatabaseHelper.USERNAME,
        DatabaseHelper.PHONE, DatabaseHelper.SEXE, DatabaseHelper.MAJOR, DatabaseHelper.IMAGE};
        // Filter results WHERE "title" = 'My Title'
        String selection = DatabaseHelper.EMAIL + " = ?";
        String[] selectionArgs = { email };
        Cursor cursor = database.query(DatabaseHelper.TABLE_NAME, columns, selection, selectionArgs, null, null, null);
        User user = null;
        if (cursor != null && cursor.moveToFirst()) {
            user = new User(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3),
                    cursor.getString(4), cursor.getString(5), cursor.getString(6));
            cursor.close();
        }
        return user;
    }

    public static void updateUser(String email, User newUser) {
        ContentValues values = new ContentValues();
        User user = selectUser(email);
        if (!user.getEmail().equals(newUser.getEmail()))
            values.put(DatabaseHelper.EMAIL, newUser.getEmail());
        if (!user.getPassword().equals(newUser.getPassword()))
            values.put(DatabaseHelper.PASSWORD, newUser.getPassword());
        if (!user.getUsername().equals(newUser.getUsername()))
            values.put(DatabaseHelper.USERNAME, newUser.getUsername());
        if (!user.getPhone().equals(newUser.getPhone()))
            values.put(DatabaseHelper.PHONE, newUser.getPhone());
        if (!user.getSexe().equals(newUser.getSexe()))
            values.put(DatabaseHelper.SEXE, newUser.getSexe());
        if (!user.getMajor().equals(newUser.getMajor()))
            values.put(DatabaseHelper.MAJOR, newUser.getMajor());
        if (!user.getImagePath().equals(newUser.getImagePath()))
            values.put(DatabaseHelper.IMAGE, newUser.getImagePath());
        if (values != null)
            database.update("USERS", values, "email=?", new String[]{email});
    }
}
