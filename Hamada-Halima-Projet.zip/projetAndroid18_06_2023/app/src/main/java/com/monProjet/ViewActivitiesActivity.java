package com.monProjet;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class ViewActivitiesActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private final float[] gravity = new float[3];
    private final float[] linear_acceleration = new float[3];
    private TextView StandingProba;
    private TextView SittingProba;
    private TextView WalkingProba;
    private TextView JumpingProba;
    private final int[] confidences = new int[4];
    String user_email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_activities);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Your activities");
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#62B1EF")));

        Intent intent = getIntent();
        user_email = intent.getStringExtra("email");

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        StandingProba = findViewById(R.id.StandingTextView);
        SittingProba = findViewById(R.id.SittingTextView);
        WalkingProba = findViewById(R.id.WalkingTextView);
        JumpingProba = findViewById(R.id.JumpingTextView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }


    private int getActivity(float[] acceleration) {
        int activity;

        float x = acceleration[0];
        float y = acceleration[1];
        float z = acceleration[2];
        float magnitude = (float) Math.sqrt(x * x + y * y + z * z);

        if (magnitude < 2.0f)
            activity = 0; // Debout
        else if (magnitude < 5.0f)
            activity = 1; // Assis
        else if (magnitude < 8.0f)
            activity = 2; // Marcher
        else
            activity = 3; // Sauter

        return activity;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.second_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.clean)
            return true;
        if (itemId == android.R.id.home) {
            Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
            intent.putExtra("email", user_email);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            final float alpha = 0.8f;
            gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];
            gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1];
            gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2];

            linear_acceleration[0] = event.values[0] - gravity[0];
            linear_acceleration[1] = event.values[1] - gravity[1];
            linear_acceleration[2] = event.values[2] - gravity[2];

            int activity = getActivity(linear_acceleration);

            confidences[activity] += 1;
            int totalConfidence = 0;
            for (int confidence : confidences) {
                totalConfidence += confidence;
            }
            if (totalConfidence > 0) {
                StandingProba.setText((confidences[0] * 100 / totalConfidence) + "%");
                SittingProba.setText((confidences[1] * 100 / totalConfidence) + "%");
                WalkingProba.setText((confidences[2] * 100 / totalConfidence) + "%");
                JumpingProba.setText((confidences[3] * 100 / totalConfidence) + "%");
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}