package com.example.hamadahalimaatelier7;

import android.annotation.SuppressLint;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private final float[] gravity = new float[3];
    private final float[] linear_acceleration = new float[3];
    private TextView StandingProba;
    private TextView SittingProba;
    private TextView WalkingProba;
    private TextView JumpingProba;
    private final int[] confidences = new int[4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        StandingProba = findViewById(R.id.StandingTextView);
        SittingProba = findViewById(R.id.SittingTextView);
        WalkingProba = findViewById(R.id.WalkingTextView);
        JumpingProba = findViewById(R.id.JumpingTextView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(listener, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener((SensorEventListener) this);
    }

    private final SensorEventListener listener = new SensorEventListener() {
        @SuppressLint("SetTextI18n")
        @Override
        public void onSensorChanged(@NonNull SensorEvent event) {
            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                final float alpha = 0.8f;
                gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];
                gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1];
                gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2];

                linear_acceleration[0] = event.values[0] - gravity[0];
                linear_acceleration[1] = event.values[1] - gravity[1];
                linear_acceleration[2] = event.values[2] - gravity[2];

                int activity = getActivity(linear_acceleration);

                confidences[activity] += 1;
                int totalConfidence = 0;
                for (int confidence : confidences) {
                    totalConfidence += confidence;
                }
                if (totalConfidence > 0) {
                    StandingProba.setText((confidences[0] * 100 / totalConfidence) + "%");
                    SittingProba.setText((confidences[1] * 100 / totalConfidence) + "%");
                    WalkingProba.setText((confidences[2] * 100 / totalConfidence) + "%");
                    JumpingProba.setText((confidences[3] * 100 / totalConfidence) + "%");
                }
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {
        }
    };

    private int getActivity(float[] acceleration) {
        int activity;

        float x = acceleration[0];
        float y = acceleration[1];
        float z = acceleration[2];
        float magnitude = (float) Math.sqrt(x * x + y * y + z * z);

        if (magnitude < 2.0f)
            activity = 0; // Debout
        else if (magnitude < 5.0f)
            activity = 1; // Assis
        else if (magnitude < 8.0f)
            activity = 2; // Marcher
        else
            activity = 3; // Sauter

        return activity;
    }
}