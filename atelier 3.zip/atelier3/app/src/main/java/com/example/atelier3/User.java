package com.example.atelier3;

import androidx.annotation.NonNull;
import androidx.room.Entity;

@Entity(tableName = "user_table", primaryKeys = {"userFirstName", "userLastName"})
public class User {
    @NonNull
    private final String userFirstName;
    @NonNull
    private final String userLastName;

    public User(@NonNull String userFirstName, @NonNull String userLastName) {
        this.userFirstName = userFirstName;
        this.userLastName = userLastName;
    }

    @NonNull
    public String getUserFirstName(){return this.userFirstName;}

    @NonNull
    public String getUserLastName(){return this.userLastName;}

    public String getFullName() {return this.getUserFirstName() + " " + this.getUserLastName();}
}
