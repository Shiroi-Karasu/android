package com.example.atelier3;

import android.app.Application;

import java.util.List;

public class UserRepository {
        private final UserDAO userDao;
        private final List<User> AllUsers;

        UserRepository(Application application) {
            UserRoomDatabase db = UserRoomDatabase.getDatabase(application);
            userDao = db.userDAO();
            AllUsers = userDao.getAlphabetizedUsers();
        }

        List<User> getAllUsers() {
            return AllUsers;
        }

        void insert(User user) {
            UserRoomDatabase.databaseWriteExecutor.execute(() -> userDao.insert(user));
        }
}
